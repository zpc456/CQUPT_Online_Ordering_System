create
    definer = root@localhost procedure HuanQian_02(IN payment_no_x char(10), IN loan_no_y char(10), IN payment_k int,
                                                   OUT error_num int, OUT remain_payment int)
label:BEGIN
		DECLARE Paymentamount INT;
		IF (SELECT amount 			 
			FROM loan
			WHERE loan_number = loan_no_y) IS NULL THEN
			SET error_num=-1;
            SET remain_payment=-1;
            LEAVE label;
		END IF;
        #修改payment表
		IF	(SELECT payment_amount 			#不存在借款账户
			 FROM payment
			 WHERE payment_number = payment_no_x) IS NULL THEN
			INSERT INTO payment values (loan_no_y,payment_no_x,payment_k,SYSDATE());
		ELSE 
			UPDATE payment
			SET payment_amount=payment_amount+payment_k
			WHERE payment_number=payment_no_x;
		END IF;
        
        #mysql的异常处理机制
 #       DECLARE exit HANDLER FOR SQLSTATE '23000' ,SQLSTATE '42000',SQLSTATE ''
 #       SET ;
        
        #修改loan表
		SELECT payment_amount into Paymentamount#这里出现错误
		FROM payment
		WHERE payment_number=payment_no_x;
        
		SELECT amount-Paymentamount into remain_payment
		FROM loan
		WHERE loan_number=loan_no_y;
        
        SELECT Paymentamount,remain_payment;#检查
        
		IF remain_payment<=0 THEN
			UPDATE loan
			SET PayOverDate = SYSDATE()
			WHERE loan_number=loan_no_y ;
		END IF;
        SET error_num=0;
		SELECT Paymentamount,remain_payment,error_num;#检查
    END label;

