create
    definer = root@localhost procedure PTransfer(IN account_no_x char(10), IN account_no_y char(10), IN amount_k int,
                                                 OUT ErrorVar int)
label:BEGIN
		IF  (SELECT balance 
			 FROM account 
			 WHERE account_number = account_no_x) IS NULL 
			OR
			(SELECT balance 
			 FROM account 
			 WHERE account_number = account_no_y) IS NULL THEN
			SET ErrorVar=-1;
			LEAVE label;
		END IF;
		#######
		UPDATE account	
		SET balance = balance + amount_k
		WHERE account_number = account_no_y;
		#-（1）**********X账号减去k元***********
		UPDATE account
		SET balance = balance - amount_k
		WHERE account_number = account_no_x;
        
        SET ErrorVar=0; 
		COMMIT;
        
	END label;

