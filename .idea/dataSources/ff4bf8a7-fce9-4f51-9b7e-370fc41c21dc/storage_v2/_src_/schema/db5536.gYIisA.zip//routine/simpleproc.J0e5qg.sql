create
    definer = root@localhost procedure simpleproc(OUT paraml int)
select count(*) into paraml from cqupt;

