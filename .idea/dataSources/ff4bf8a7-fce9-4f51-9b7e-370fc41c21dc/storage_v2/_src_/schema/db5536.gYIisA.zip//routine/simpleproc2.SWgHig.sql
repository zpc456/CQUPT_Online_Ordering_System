create
    definer = root@localhost procedure simpleproc2(IN param int)
    set @x=param;

