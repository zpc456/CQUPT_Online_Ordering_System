create
    definer = root@localhost procedure simpleprocl(IN param2 int)
    set @x=param2-100;

