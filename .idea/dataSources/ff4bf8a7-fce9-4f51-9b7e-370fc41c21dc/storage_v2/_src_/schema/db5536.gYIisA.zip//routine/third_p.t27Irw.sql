create
    definer = root@localhost procedure third_p()
select * from cqupt;

